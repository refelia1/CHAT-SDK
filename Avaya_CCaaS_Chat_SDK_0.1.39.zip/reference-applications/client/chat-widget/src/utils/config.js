export const CUSTOMER = "CUSTOMER";
export const SYSTEM = "SYSTEM";
export const BOT = "BOT";
export const AGENT = "AGENT";
export const SUPERVISOR = "SUPERVISOR";
