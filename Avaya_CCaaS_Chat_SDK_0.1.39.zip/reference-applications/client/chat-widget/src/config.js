export const API_URL='https://chatconnector.westeurope.cloudapp.azure.com'
export const CHAT_WINDOW_NAME="chat-window"
